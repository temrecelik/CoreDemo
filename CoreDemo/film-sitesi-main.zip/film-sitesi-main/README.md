<center>𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐢𝐯𝐞 𝐅𝐢𝐥𝐦 𝐖𝐞𝐛𝐬𝐢𝐭𝐞</center>
<hr>
I have builded a responsive film website using Html, Css and JavaScript.

Features: navbar, sidebar, JavaScript Slider, Css and JavaScript Darkmode







![GIFMaker_me (1) (4)](https://github.com/funwithpeeves/film-sitesi/assets/164248954/9a8f6777-107a-4ea5-b4ed-dc41e68dda44)
